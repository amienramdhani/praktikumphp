<h1>Detail Transaksi</h1>
	<hr>
	Nama     : <?= $view_transaksi['name'];?><br/>
	Alamat   : <?= $view_transaksi['address'];?><br/>
	Gender   : <?= $view_transaksi['gender'];?><br/>
	Status   : <?= $view_transaksi['status'];?><br/>
  Amount   : <?= $view_transaksi['amount'];?><br/>
  Tanggal  : <?= $view_transaksi['created_date'];?><br/>
  Saldo    : <?= $balance['balance'];?><br/>
	<hr>
